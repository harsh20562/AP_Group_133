module com.example.willhero {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;


    opens com.example.willhero to javafx.fxml;
    exports com.example.willhero;
}