package com.example.willhero;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class GamePage {
    private static int id = 0;
    private int coins;
    private int gameid;
    private int score;
    GamePage()
    {
        this.coins = 0;
        this.score = 0;
        this.gameid = id;
        this.id = this.id + 1;
    }

    public int getCoins() {
        return coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public int getGameid() {
        return gameid;
    }

    public void setGameid(int gameid) {
        this.gameid = gameid;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setgame(Stage stage) throws IOException {
        Parent gamepage_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("game-page.fxml")));
        Scene scene = new Scene(gamepage_root,500,600);
        stage.setScene(scene);
        stage.show();
    }
}
