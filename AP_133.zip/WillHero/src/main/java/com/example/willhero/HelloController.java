package com.example.willhero;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class HelloController {
    //private ObservableList<GamePage> game_collection = FXCollections.observableArrayList();
    @FXML
    private ImageView play;
    @FXML
    private ImageView exit;
    @FXML
    private ImageView settings;
    @FXML
    private ImageView leaderboard;
    @FXML
    public void exitgame(MouseEvent e)
    {
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setContentText("Would you like to exit the game ?");
        ButtonType okButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
        alert.getButtonTypes().setAll(okButton, noButton);
        alert.showAndWait().ifPresent(type -> {
            if (type == okButton) {
                alert.close();
                stage.close();
            }
            else if (type == noButton) {
                alert.close();
            }
        });
    }
    @FXML
    public void playgame(MouseEvent e) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Play");
        alert.setContentText("What would you like to choose ?");
        ButtonType okButton = new ButtonType("New Game", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("Load Game", ButtonBar.ButtonData.NO);
        alert.getButtonTypes().setAll(okButton, noButton);
        alert.showAndWait().ifPresent(type -> {
            if (type == okButton) {
                try {
                    Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
                    new_game(stage);
                } catch (IOException exception) {
                    System.out.println("Function not called");
                }
            } else if (type == noButton) {
            }
        });
    }

    @FXML
    public void set_settings(MouseEvent e) throws IOException {
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        Parent actualGame_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("settings.fxml")));
        Scene scene = new Scene(actualGame_root,500,600);
        stage.setScene(scene);
        stage.show();
    }

    public void showleaderboard()
    {

    }
    @FXML
    public void new_game(Stage stage) throws IOException {
        GamePage newgame = new GamePage();
        newgame.setgame(stage);
    }
}
