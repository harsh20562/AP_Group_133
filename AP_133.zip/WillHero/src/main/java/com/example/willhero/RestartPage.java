package com.example.willhero;

import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class RestartPage implements Initializable {
    @FXML
    private ImageView cloud1;
    @FXML
    private ImageView cloud2;
    @FXML
    private ImageView cloud3;
    @FXML
    private ImageView cloud4;
    @FXML
    private AnchorPane restartPane;

    @FXML
    private void set_mainmenu(MouseEvent e) throws IOException {
        Stage stage = (Stage)(cloud1.getScene().getWindow());
        Parent restart_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("mainmenu.fxml")));
        Scene scene = new Scene(restart_root,500,600);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        TranslateTransition translate1 = new TranslateTransition();
        {
            translate1.setDuration(Duration.millis(2000));
            translate1.setCycleCount(Timeline.INDEFINITE);
            translate1.setAutoReverse(true);
            translate1.setNode(cloud1);
            translate1.setByX(200);
            translate1.play();
            translate1.setNode(cloud3);
            translate1.play();
        }
        TranslateTransition translate2 = new TranslateTransition();
        {
            translate2.setDuration(Duration.millis(2000));
            translate2.setCycleCount(Timeline.INDEFINITE);
            translate2.setAutoReverse(true);
            translate2.setNode(cloud2);
            translate2.setByX(-200);
            translate2.play();
            translate2.setNode(cloud4);
            translate2.play();
        }
    }

}
