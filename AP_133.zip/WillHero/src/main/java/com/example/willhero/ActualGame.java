package com.example.willhero;

import javafx.animation.AnimationTimer;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import java.util.ResourceBundle;

public class ActualGame implements Initializable {
    @FXML
    private ImageView hero;
    @FXML
    private Rectangle rectangle;
    @FXML
    private ImageView orc1,orc2,orc3,orc4,orc5,boss;
    @FXML
    private AnchorPane gamepane;
    @FXML
    private ImageView island1,island2,island3,island4,island5,island6,island7,island8;
    @FXML
    private ImageView target;
    @FXML
    private ImageView coin1,coin2,coin3,coin4,coin5,coin6;
    @FXML
    private ImageView chest1,chest2;
    private Image img = new Image("https://raw.githubusercontent.com/harsh20562/Will-Hero-Images/main/Will%20Hero%20Images/ChestOpen.jpg");
    private int coins_total = 0;
    private Stage stage;

    boolean stoptimer = false;

    private Point2D playerVelocity = new Point2D(0, 0);
    private ArrayList<Node> platforms = new ArrayList<Node>();
    private ArrayList<Node> coins = new ArrayList<Node>();
    private ArrayList<Node> orcs = new ArrayList<Node>();
    private  ArrayList<Node> tnts = new ArrayList<Node>();
    private  ArrayList<Node> chests = new ArrayList<Node>();

    @FXML
    public void move_hero(MouseEvent e)
    {
        movePlayerX(70);
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
    }

    private void movePlayerX(int value) {
        boolean movingRight = value > 0;

        for (int i = 0; i < Math.abs(value); i++) {
            for (Node platform : orcs) {
                if (hero.getBoundsInParent().intersects(platform.getBoundsInParent())) {
                    if (movingRight) {
                        if (hero.getTranslateX() + 70 == platform.getTranslateX()) {
                            return;
                        }
                    }
                    else {
                        if (hero.getTranslateX() == platform.getTranslateX() + 70) {
                            return;
                        }
                    }
                }
            }
            hero.setTranslateX(hero.getTranslateX() + (movingRight ? 1 : -1));
        }
    }

    public void check_coins()
    {
        for (Node c : coins)
        {
            if (hero.getBoundsInParent().intersects(c.getBoundsInParent())) {
                coins_total = coins_total + 1;
                gamepane.getChildren().remove(c);
            }
        }
    }

    public void check_chests()
    {
        for (Node c : chests)
        {
            if (hero.getBoundsInParent().intersects(c.getBoundsInParent())) {
                int y = (int)c.getTranslateY();
                coins_total = coins_total + 5;
                ImageView r = (ImageView)c;
                r.setImage(img);
                r.setY(y-15);
            }
        }
    }

    public void check_losing_condition() throws IOException {
        for(Node orc: orcs)
        {
            if((int)hero.getTranslateX()+50>=(int)orc.getTranslateX() && (int)hero.getTranslateY()> (int)hero.getTranslateY())
            {
                stoptimer = true;
                //Stage stage = (Stage)(gamepane.getScene().getWindow());
                Parent restart_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("restart-page.fxml")));
                Scene scene = new Scene(restart_root,500,600);
                stage.setScene(scene);
                stage.show();
            }
        }
    }

    public void addOrcs()
    {
        orcs.add(orc1);
        orcs.add(orc2);
        orcs.add(orc3);
        orcs.add(orc4);
        orcs.add(orc5);
        orcs.add(boss);
        for(Node o: orcs)
        {
            TranslateTransition translate = new TranslateTransition();
            {
                translate.setDuration(Duration.millis(500));
                translate.setCycleCount(Timeline.INDEFINITE);
                translate.setAutoReverse(true);
                translate.setNode(o);
                translate.setByY(-70);
                translate.play();
            }
        }
    }

    public void check_winning_conditions() throws IOException {
        if(hero.getBoundsInParent().intersects(target.getBoundsInParent()))
        {
            stoptimer = true;
            Parent restart_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("restart-page.fxml")));
            //Stage stage = (Stage)hero.getScene().getWindow();
            Scene scene = new Scene(restart_root,500,600);
            stage.setScene(scene);
            stage.show();
        }
    }

    private void addCoins()
    {
        coins.add(coin1);
        coins.add(coin2);
        coins.add(coin3);
        coins.add(coin4);
        coins.add(coin5);
        coins.add(coin6);
    }
    private void addChests()
    {
        chests.add(chest1);
        chests.add(chest2);
    }

    public void update() throws IOException {
        check_coins();
        check_chests();
        check_winning_conditions();
        check_losing_condition();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        platforms.add(island1);
        platforms.add(island2);
        platforms.add(island3);
        platforms.add(island4);
        platforms.add(island5);
        platforms.add(island6);
        platforms.add(island7);
        platforms.add(island8);
        addOrcs();
        addCoins();
        addChests();
        TranslateTransition translate = new TranslateTransition();
        {
            translate.setDuration(Duration.millis(500));
            translate.setCycleCount(Timeline.INDEFINITE);
            translate.setAutoReverse(true);
            translate.setNode(hero);
            translate.setByY(-70);
            translate.play();
        }
        hero.translateXProperty().addListener((obs, old, newValue) -> {
            int offset = newValue.intValue();
            int poffset = old.intValue();
            if (offset > 250 && poffset<2250) {
                gamepane.setLayoutX(-(offset-250));
            }
        });

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long l) {
                if(stoptimer)
                {
                    this.stop();
                }
                try {
                    update();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        timer.start();
    }
}
