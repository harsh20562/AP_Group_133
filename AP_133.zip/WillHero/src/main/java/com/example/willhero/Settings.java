package com.example.willhero;

import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.io.File;

public class Settings implements Initializable {
    @FXML
    private ImageView cloud1;
    @FXML
    private ImageView cloud2;
    @FXML
    private ImageView back;
    @FXML
    private CheckBox box;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        TranslateTransition translate1 = new TranslateTransition();
        {
            translate1.setDuration(Duration.millis(2000));
            translate1.setCycleCount(Timeline.INDEFINITE);
            translate1.setAutoReverse(true);
            translate1.setNode(cloud1);
            translate1.setByX(200);
            translate1.play();
        }
        TranslateTransition translate2 = new TranslateTransition();
        {
            translate2.setDuration(Duration.millis(2000));
            translate2.setCycleCount(Timeline.INDEFINITE);
            translate2.setAutoReverse(true);
            translate2.setNode(cloud2);
            translate2.setByX(-200);
            translate2.play();
        }
        play_music();
    }
    @FXML
    public void back_button(MouseEvent e) throws IOException {
        Stage stage = (Stage)(back.getScene().getWindow());
        Parent mainmenu_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("mainmenu.fxml")));
        Scene scene = new Scene(mainmenu_root,500,600);
        stage.setScene(scene);
        stage.show();
    }
    public void play_music()
    {
        String musicFile = "C:\\Users\\harsh\\Desktop\\Projects\\Java\\JavaFX\\WillHero\\src\\main\\resources\\com\\example\\willhero\\audio_pvz.mp3";
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
}
