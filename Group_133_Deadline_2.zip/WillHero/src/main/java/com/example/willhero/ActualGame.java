package com.example.willhero;

import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

public class ActualGame implements Initializable {
    @FXML
    private ImageView hero;
    @FXML
    private Rectangle rectangle;
    @FXML
    private ImageView orc1;


    @FXML
    public void move_hero(MouseEvent e)
    {
        TranslateTransition translate = new TranslateTransition();
        {
            translate.setDuration(Duration.millis(200));
            translate.setCycleCount(1);
            translate.setAutoReverse(false);
            translate.setNode(hero);
            translate.setByX(50);
            translate.play();
        }
    }

//    @FXML
//    public  void jump_Hero()
//    {
//        stage.setOnKeyPressed(new EventHandler<KeyEvent>() {
//            @Override
//            public void handle(KeyEvent event) {
//                if (event.getCode()==KeyCode.UP) {
//                    TranslateTransition translate = new TranslateTransition();
//                    {
//                        translate.setDuration(Duration.millis(500));
//                        translate.setCycleCount(1);
//                        translate.setAutoReverse(true);
//                        translate.setNode(hero);
//                        translate.setByY(-80);
//                        translate.play();
//                        translate.setDuration(Duration.millis(200));
//                        translate.setCycleCount(1);
//                        translate.setAutoReverse(false);
//                        translate.setNode(hero);
//                        translate.setByX(50);
//                        translate.play();
//                    }
//                }
//            }
//        });
//    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        Image cloud = new Image("https://raw.githubusercontent.com/harsh20562/Will-Hero-Images/main/Island%20Images/cloud.png?token=AVDRJMIC6KZNWKFAEIKF5MLBXI7K6");
        Image i1 = new Image("https://raw.githubusercontent.com/harsh20562/Will-Hero-Images/main/Island%20Images/island1.png?token=AVDRJMMETITG6Q5LRRZY773BXI7M2");
        ArrayList<Image> island_img = new ArrayList<>();
        island_img.add(i1);
        i1 = new Image("https://raw.githubusercontent.com/harsh20562/Will-Hero-Images/main/Island%20Images/island2.png?token=AVDRJMP5DOKFNVYFOW3KB2LBXI7YS");
        island_img.add(i1);
        i1 = new Image("https://raw.githubusercontent.com/harsh20562/Will-Hero-Images/main/Island%20Images/island3.png?token=AVDRJMMVJYQ4BOI6JKLM2HTBXI776");
        island_img.add(i1);
        i1 = new Image("https://raw.githubusercontent.com/harsh20562/Will-Hero-Images/main/Island%20Images/island4.png?token=AVDRJMLSIHVWVW2JCFG7WQDBXJAC2");
        island_img.add(i1);
        ImageView islands = new ImageView();
        int size = island_img.size();
        Random rand = new Random();
        int low = 0;
        int high = 3;
        int island_type = rand.nextInt(high-low) + low;
        TranslateTransition translate = new TranslateTransition();
        {
            translate.setDuration(Duration.millis(500));
            translate.setCycleCount(Timeline.INDEFINITE);
            translate.setAutoReverse(true);
            translate.setNode(hero);
            translate.setByY(-80);
            translate.play();
            translate.setNode(orc1);
            translate.play();
        }
    }
}
