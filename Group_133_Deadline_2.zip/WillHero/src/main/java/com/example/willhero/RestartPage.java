package com.example.willhero;

import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class RestartPage implements Initializable {
    @FXML
    private ImageView cloud1;
    @FXML
    private ImageView cloud2;
    @FXML
    private ImageView cloud3;
    @FXML
    private ImageView cloud4;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        TranslateTransition translate1 = new TranslateTransition();
        {
            translate1.setDuration(Duration.millis(2000));
            translate1.setCycleCount(Timeline.INDEFINITE);
            translate1.setAutoReverse(true);
            translate1.setNode(cloud1);
            translate1.setByX(200);
            translate1.play();
            translate1.setNode(cloud3);
            translate1.play();
        }
        TranslateTransition translate2 = new TranslateTransition();
        {
            translate2.setDuration(Duration.millis(2000));
            translate2.setCycleCount(Timeline.INDEFINITE);
            translate2.setAutoReverse(true);
            translate2.setNode(cloud2);
            translate2.setByX(-200);
            translate2.play();
            translate2.setNode(cloud4);
            translate2.play();
        }
    }

}
