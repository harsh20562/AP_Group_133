package com.example.willhero;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class GamePageController implements Initializable {
    @FXML
    private ImageView back;
    @FXML
    private ImageView settings;
    @FXML
    private ImageView image;
    @FXML
    private ImageView play;
    @FXML
    private Text will;
    @FXML
    private Text hero;
    @FXML
    private Text coinvalue;
    @FXML
    public void back_button(MouseEvent e) throws IOException {
        Stage stage = (Stage)(back.getScene().getWindow());
        Parent mainmenu_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("mainmenu.fxml")));
        Scene scene = new Scene(mainmenu_root,500,600);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void play_button(MouseEvent e) throws IOException {
        Stage stage = (Stage)(play.getScene().getWindow());
        Parent actualGame_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("actual-game.fxml")));
        Scene scene = new Scene(actualGame_root,500,600);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void set_settings(MouseEvent e) throws IOException {
        Stage stage = (Stage)(settings.getScene().getWindow());
        Parent actualGame_root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("settings.fxml")));
        Scene scene = new Scene(actualGame_root,500,600);
        stage.setScene(scene);
        stage.show();
    }

    public void rotate_all(Node node)
    {
        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(360);
        rotate.setCycleCount(Timeline.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.setDuration(Duration.millis(1000));
        rotate.setAutoReverse(false);
        rotate.setNode(node);
        rotate.play();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        rotate_all(will);
        rotate_all(hero);
        rotate_all(image);
    }
}
